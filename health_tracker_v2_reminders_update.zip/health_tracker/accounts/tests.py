import datetime

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone

from .models import Profile

User = get_user_model()


class QuietHoursTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ana', password='pw')

    def _at(self, hour, minute=0):
        today = timezone.localdate()
        naive = datetime.datetime.combine(today, datetime.time(hour, minute))
        return timezone.make_aware(naive)

    def test_no_window_configured_is_never_quiet(self):
        profile = Profile.objects.create(user=self.user)
        self.assertFalse(profile.is_within_quiet_hours(self._at(23)))

    def test_same_day_window(self):
        profile = Profile.objects.create(
            user=self.user,
            quiet_hours_start=datetime.time(13, 0),
            quiet_hours_end=datetime.time(15, 0),
        )
        self.assertTrue(profile.is_within_quiet_hours(self._at(14)))
        self.assertFalse(profile.is_within_quiet_hours(self._at(12)))
        self.assertFalse(profile.is_within_quiet_hours(self._at(15)))  # end is exclusive

    def test_overnight_window(self):
        profile = Profile.objects.create(
            user=self.user,
            quiet_hours_start=datetime.time(21, 0),
            quiet_hours_end=datetime.time(7, 0),
        )
        self.assertTrue(profile.is_within_quiet_hours(self._at(23)))
        self.assertTrue(profile.is_within_quiet_hours(self._at(2)))
        self.assertTrue(profile.is_within_quiet_hours(self._at(6, 59)))
        self.assertFalse(profile.is_within_quiet_hours(self._at(7)))
        self.assertFalse(profile.is_within_quiet_hours(self._at(12)))

    def test_only_one_bound_set_behaves_as_no_window(self):
        profile = Profile.objects.create(user=self.user, quiet_hours_start=datetime.time(21, 0))
        self.assertFalse(profile.is_within_quiet_hours(self._at(23)))


class QuietHoursFormTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ana', password='pw')
        self.profile = Profile.objects.create(user=self.user)

    def test_requires_both_bounds_or_neither(self):
        from .forms import QuietHoursForm

        form = QuietHoursForm(data={'quiet_hours_start': '21:00'}, instance=self.profile)
        self.assertFalse(form.is_valid())

    def test_both_bounds_saves_cleanly(self):
        from .forms import QuietHoursForm

        form = QuietHoursForm(
            data={'quiet_hours_start': '21:00', 'quiet_hours_end': '07:00'},
            instance=self.profile,
        )
        self.assertTrue(form.is_valid(), form.errors)
