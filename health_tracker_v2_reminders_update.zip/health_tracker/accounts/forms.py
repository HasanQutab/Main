from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Profile


class RegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def clean_email(self):
        email = self.cleaned_data['email']
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError('An account with this email already exists.')
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user


class UserBasicForm(forms.ModelForm):
    """Editable fields that live on the built-in User model."""

    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email')

    def clean_email(self):
        email = self.cleaned_data['email']
        if User.objects.filter(email__iexact=email).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError('An account with this email already exists.')
        return email


class ProfileDetailsForm(forms.ModelForm):
    """Editable fields that live on the Profile model (Phase 3)."""

    class Meta:
        model = Profile
        fields = ('bio', 'date_of_birth', 'height_cm', 'weight_kg')
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 3}),
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
        }


class QuietHoursForm(forms.ModelForm):
    """Lets a user set a window during which hourly reminders go silent."""

    class Meta:
        model = Profile
        fields = ('quiet_hours_start', 'quiet_hours_end')
        widgets = {
            'quiet_hours_start': forms.TimeInput(attrs={'type': 'time'}, format='%H:%M'),
            'quiet_hours_end': forms.TimeInput(attrs={'type': 'time'}, format='%H:%M'),
        }

    def clean(self):
        cleaned_data = super().clean()
        start = cleaned_data.get('quiet_hours_start')
        end = cleaned_data.get('quiet_hours_end')
        if bool(start) != bool(end):
            raise forms.ValidationError('Set both a start and an end time, or leave both blank.')
        return cleaned_data
