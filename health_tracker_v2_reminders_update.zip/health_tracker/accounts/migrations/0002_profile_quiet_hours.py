from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('accounts', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='profile',
            name='quiet_hours_start',
            field=models.TimeField(
                blank=True, null=True,
                help_text="Hourly reminders (like water) won't be sent from this time...",
            ),
        ),
        migrations.AddField(
            model_name='profile',
            name='quiet_hours_end',
            field=models.TimeField(
                blank=True, null=True,
                help_text='...until this time. Leave both blank to disable quiet hours.',
            ),
        ),
    ]
