from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError, transaction
from django.shortcuts import redirect, render

from .forms import ProfileDetailsForm, QuietHoursForm, RegistrationForm, UserBasicForm
from .models import Profile


def register(request):
    if request.user.is_authenticated:
        return redirect('dashboard:home')

    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    user = form.save()
            except IntegrityError:
                # Belt-and-braces: covers a double-submit or a race where two
                # requests both pass validation with the same username before
                # either has saved.
                form.add_error('username', 'A user with that username already exists.')
            else:
                login(request, user)
                messages.success(request, 'Your account has been created.')
                return redirect('dashboard:home')
    else:
        form = RegistrationForm()

    return render(request, 'accounts/register.html', {'form': form})


@login_required
def profile(request):
    profile_obj, _ = Profile.objects.get_or_create(user=request.user)
    user_form = UserBasicForm(instance=request.user)
    profile_form = ProfileDetailsForm(instance=profile_obj)
    quiet_hours_form = QuietHoursForm(instance=profile_obj)

    if request.method == 'POST':
        if request.POST.get('form_type') == 'profile':
            profile_form = ProfileDetailsForm(request.POST, instance=profile_obj)
            if profile_form.is_valid():
                profile_form.save()
                messages.success(request, 'Your profile has been updated.')
                return redirect('accounts:profile')
        elif request.POST.get('form_type') == 'quiet_hours':
            quiet_hours_form = QuietHoursForm(request.POST, instance=profile_obj)
            if quiet_hours_form.is_valid():
                quiet_hours_form.save()
                messages.success(request, 'Quiet hours updated.')
                return redirect('accounts:profile')
        else:
            user_form = UserBasicForm(request.POST, instance=request.user)
            if user_form.is_valid():
                user_form.save()
                messages.success(request, 'Your profile has been updated.')
                return redirect('accounts:profile')

    return render(request, 'accounts/profile.html', {
        'user_form': user_form,
        'profile_form': profile_form,
        'quiet_hours_form': quiet_hours_form,
    })
