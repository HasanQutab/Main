from django.conf import settings
from django.db import models
from django.utils import timezone


class Profile(models.Model):
    """Extended, non-authentication information about a user.

    Added in Phase 3, alongside health and habit tracking.
    """

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='profile',
    )
    bio = models.TextField(blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    height_cm = models.DecimalField(
        max_digits=5, decimal_places=1, null=True, blank=True,
        help_text='Height in centimeters.',
    )
    weight_kg = models.DecimalField(
        max_digits=5, decimal_places=1, null=True, blank=True,
        help_text='Current weight in kilograms.',
    )
    quiet_hours_start = models.TimeField(
        null=True, blank=True,
        help_text="Hourly reminders (like water) won't be sent from this time...",
    )
    quiet_hours_end = models.TimeField(
        null=True, blank=True,
        help_text='...until this time. Leave both blank to disable quiet hours.',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Profile for {self.user.username}'

    def is_within_quiet_hours(self, when):
        """True if `when` (a timezone-aware datetime) falls inside this
        user's quiet-hours window, in their local time. Handles windows
        that cross midnight (e.g. 22:00 -> 07:00). Returns False if quiet
        hours aren't configured."""
        start, end = self.quiet_hours_start, self.quiet_hours_end
        if not start or not end:
            return False
        local_time = timezone.localtime(when).time()
        if start <= end:
            return start <= local_time < end
        return local_time >= start or local_time < end
