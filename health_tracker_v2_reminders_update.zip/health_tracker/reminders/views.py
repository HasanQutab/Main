from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import ReminderForm
from .models import Reminder


@login_required
def reminder_list(request):
    now = timezone.now()
    reminders = Reminder.objects.filter(user=request.user)
    upcoming = reminders.filter(is_active=True, remind_at__gte=now).order_by('remind_at')
    past = reminders.exclude(pk__in=upcoming.values('pk')).order_by('-remind_at')
    return render(request, 'reminders/list.html', {'upcoming': upcoming, 'past': past})


@login_required
def reminder_create(request):
    if request.method == 'POST':
        form = ReminderForm(request.POST)
        if form.is_valid():
            reminder = form.save(commit=False)
            reminder.user = request.user
            reminder.save()
            messages.success(request, 'Reminder created.')
            return redirect('reminders:list')
    else:
        form = ReminderForm(initial={'remind_at': timezone.localtime()})
    return render(request, 'reminders/form.html', {'form': form, 'is_edit': False})


@login_required
def reminder_edit(request, pk):
    reminder = get_object_or_404(Reminder, pk=pk, user=request.user)
    if request.method == 'POST':
        form = ReminderForm(request.POST, instance=reminder)
        if form.is_valid():
            form.save()
            messages.success(request, 'Reminder updated.')
            return redirect('reminders:list')
    else:
        form = ReminderForm(instance=reminder)
    return render(request, 'reminders/form.html', {'form': form, 'is_edit': True})


@login_required
def reminder_delete(request, pk):
    reminder = get_object_or_404(Reminder, pk=pk, user=request.user)
    if request.method == 'POST':
        reminder.delete()
        messages.success(request, 'Reminder deleted.')
        return redirect('reminders:list')
    return render(request, 'reminders/confirm_delete.html', {'reminder': reminder})


@login_required
def reminder_toggle(request, pk):
    reminder = get_object_or_404(Reminder, pk=pk, user=request.user)
    if request.method == 'POST':
        reminder.is_active = not reminder.is_active
        reminder.save()
    return redirect('reminders:list')
