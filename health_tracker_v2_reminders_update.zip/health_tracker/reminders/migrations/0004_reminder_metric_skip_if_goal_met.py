from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('reminders', '0003_reminder_hourly_repeat'),
    ]

    operations = [
        migrations.AddField(
            model_name='reminder',
            name='metric',
            field=models.CharField(
                blank=True,
                choices=[
                    ('none', 'Not linked to a metric'),
                    ('steps', 'Steps'),
                    ('water', 'Water'),
                    ('sleep', 'Sleep'),
                ],
                default='none',
                help_text="Link to a daily health metric so this reminder can check today's progress before sending.",
                max_length=10,
            ),
        ),
        migrations.AddField(
            model_name='reminder',
            name='skip_if_goal_met',
            field=models.BooleanField(
                default=False,
                help_text="Don't send this reminder once today's goal for the linked metric has already been reached.",
            ),
        ),
    ]
