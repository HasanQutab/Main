from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('reminders', '0002_reminder_last_sent_at'),
    ]

    operations = [
        migrations.AlterField(
            model_name='reminder',
            name='repeat',
            field=models.CharField(
                choices=[
                    ('none', 'Does not repeat'),
                    ('hourly', 'Hourly'),
                    ('daily', 'Daily'),
                    ('weekly', 'Weekly'),
                ],
                default='none',
                max_length=10,
            ),
        ),
    ]
