from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('reminders', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='reminder',
            name='last_sent_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
