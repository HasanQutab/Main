from django.conf import settings
from django.db import models
from django.utils import timezone


class Reminder(models.Model):
    class Repeat(models.TextChoices):
        NONE = 'none', 'Does not repeat'
        HOURLY = 'hourly', 'Hourly'
        DAILY = 'daily', 'Daily'
        WEEKLY = 'weekly', 'Weekly'

    class Metric(models.TextChoices):
        NONE = 'none', 'Not linked to a metric'
        STEPS = 'steps', 'Steps'
        WATER = 'water', 'Water'
        SLEEP = 'sleep', 'Sleep'

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='reminders',
    )
    title = models.CharField(max_length=120)
    message = models.CharField(max_length=255, blank=True)
    remind_at = models.DateTimeField()
    repeat = models.CharField(max_length=10, choices=Repeat.choices, default=Repeat.NONE)
    is_active = models.BooleanField(default=True)
    metric = models.CharField(
        max_length=10, choices=Metric.choices, default=Metric.NONE, blank=True,
        help_text="Link to a daily health metric so this reminder can check today's progress before sending.",
    )
    skip_if_goal_met = models.BooleanField(
        default=False,
        help_text="Don't send this reminder once today's goal for the linked metric has already been reached.",
    )
    last_sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('remind_at',)

    def __str__(self):
        return self.title

    @property
    def is_past_due(self):
        return self.remind_at < timezone.now()

    def advance_after_send(self, sent=True):
        """Called once a reminder has been evaluated for delivery — whether
        it was actually emailed (`sent=True`) or silently skipped because of
        quiet hours / an already-met goal (`sent=False`). Either way it
        reschedules repeating reminders to their next occurrence (so a
        skipped hourly ping doesn't leave the reminder stuck re-checking the
        same overdue timestamp), or deactivates one-off ones. last_sent_at
        only moves forward when it was actually sent."""
        update_fields = ['remind_at', 'is_active']
        if sent:
            self.last_sent_at = timezone.now()
            update_fields.append('last_sent_at')
        if self.repeat == self.Repeat.HOURLY:
            self.remind_at += timezone.timedelta(hours=1)
        elif self.repeat == self.Repeat.DAILY:
            self.remind_at += timezone.timedelta(days=1)
        elif self.repeat == self.Repeat.WEEKLY:
            self.remind_at += timezone.timedelta(days=7)
        else:
            self.is_active = False
        self.save(update_fields=update_fields)
