from django.urls import path

from . import views

app_name = 'reminders'

urlpatterns = [
    path('reminders/', views.reminder_list, name='list'),
    path('reminders/new/', views.reminder_create, name='create'),
    path('reminders/<int:pk>/edit/', views.reminder_edit, name='edit'),
    path('reminders/<int:pk>/delete/', views.reminder_delete, name='delete'),
    path('reminders/<int:pk>/toggle/', views.reminder_toggle, name='toggle'),
]
