from django import forms

from .models import Reminder


class ReminderForm(forms.ModelForm):
    class Meta:
        model = Reminder
        fields = ('title', 'message', 'remind_at', 'repeat', 'is_active', 'metric', 'skip_if_goal_met')
        widgets = {
            'remind_at': forms.DateTimeInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M'),
            'message': forms.Textarea(attrs={'rows': 2}),
        }

    def clean(self):
        cleaned_data = super().clean()
        metric = cleaned_data.get('metric')
        skip_if_goal_met = cleaned_data.get('skip_if_goal_met')
        if skip_if_goal_met and metric in (None, '', Reminder.Metric.NONE):
            self.add_error(
                'skip_if_goal_met',
                'Link this reminder to a metric (steps, water, or sleep) to skip it when the goal is met.',
            )
        return cleaned_data
