"""Lets a Reminder check whether today's health target is already met, so
send_due_reminders can skip a nudge that's no longer needed."""
from django.utils import timezone

from .models import Reminder

# Maps a Reminder.Metric onto (DailyLog field, recommended-targets key).
_METRIC_FIELDS = {
    Reminder.Metric.STEPS: ('steps', 'steps'),
    Reminder.Metric.WATER: ('water_ml', 'water_ml'),
    Reminder.Metric.SLEEP: ('sleep_hours', 'sleep_hours'),
}


def is_metric_goal_met(user, metric):
    """True if today's DailyLog value for `metric` already meets or beats
    the user's recommended target. False if the metric isn't trackable,
    there's no log yet today, or the value falls short."""
    fields = _METRIC_FIELDS.get(metric)
    if not fields:
        return False
    log_field, target_key = fields

    from health.models import DailyLog
    from health.recommendations import get_profile_for_user, get_recommended_targets

    log = DailyLog.objects.filter(user=user, date=timezone.localdate()).first()
    value = getattr(log, log_field, None) if log else None
    if not value:
        return False

    targets = get_recommended_targets(get_profile_for_user(user))
    target = targets.get(target_key)
    if not target:
        return False

    return float(value) >= float(target)
