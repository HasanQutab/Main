import datetime
from io import StringIO

from django.contrib.auth import get_user_model
from django.core import mail
from django.core.management import call_command
from django.test import TestCase
from django.utils import timezone

from accounts.models import Profile
from health.models import DailyLog

from .models import Reminder
from .services import is_metric_goal_met

User = get_user_model()


class IsMetricGoalMetTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ana', password='pw', email='ana@example.com')

    def test_no_log_today_is_not_met(self):
        self.assertFalse(is_metric_goal_met(self.user, Reminder.Metric.WATER))

    def test_value_below_target_is_not_met(self):
        DailyLog.objects.create(user=self.user, date=timezone.localdate(), water_ml=500)
        self.assertFalse(is_metric_goal_met(self.user, Reminder.Metric.WATER))

    def test_value_meeting_target_is_met(self):
        # Default water target (no profile weight on file) is 2000ml.
        DailyLog.objects.create(user=self.user, date=timezone.localdate(), water_ml=2500)
        self.assertTrue(is_metric_goal_met(self.user, Reminder.Metric.WATER))

    def test_none_metric_is_never_met(self):
        DailyLog.objects.create(user=self.user, date=timezone.localdate(), water_ml=5000)
        self.assertFalse(is_metric_goal_met(self.user, Reminder.Metric.NONE))


class SendDueRemindersCommandTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ana', password='pw', email='ana@example.com')
        self.now = timezone.now()

    def _due_reminder(self, **overrides):
        defaults = dict(
            user=self.user,
            title='Drink water',
            remind_at=self.now - datetime.timedelta(minutes=5),
            repeat=Reminder.Repeat.HOURLY,
            is_active=True,
        )
        defaults.update(overrides)
        return Reminder.objects.create(**defaults)

    def test_quiet_hours_suppress_hourly_reminder_but_reschedule_it(self):
        Profile.objects.create(
            user=self.user,
            quiet_hours_start=datetime.time(0, 0),
            quiet_hours_end=datetime.time(23, 59, 59),
        )  # basically "always quiet" for a deterministic test
        reminder = self._due_reminder()
        original_remind_at = reminder.remind_at

        out = StringIO()
        call_command('send_due_reminders', stdout=out)

        reminder.refresh_from_db()
        self.assertEqual(len(mail.outbox), 0)
        self.assertTrue(reminder.is_active)
        self.assertIsNone(reminder.last_sent_at)
        self.assertEqual(reminder.remind_at, original_remind_at + datetime.timedelta(hours=1))
        self.assertIn('skipped 1', out.getvalue())

    def test_daily_reminder_ignores_quiet_hours(self):
        Profile.objects.create(
            user=self.user,
            quiet_hours_start=datetime.time(0, 0),
            quiet_hours_end=datetime.time(23, 59, 59),
        )
        reminder = self._due_reminder(repeat=Reminder.Repeat.DAILY)

        call_command('send_due_reminders', stdout=StringIO())

        reminder.refresh_from_db()
        self.assertEqual(len(mail.outbox), 1)
        self.assertIsNotNone(reminder.last_sent_at)

    def test_skip_if_goal_met_suppresses_reminder(self):
        DailyLog.objects.create(user=self.user, date=timezone.localdate(), water_ml=3000)
        reminder = self._due_reminder(metric=Reminder.Metric.WATER, skip_if_goal_met=True)
        original_remind_at = reminder.remind_at

        call_command('send_due_reminders', stdout=StringIO())

        reminder.refresh_from_db()
        self.assertEqual(len(mail.outbox), 0)
        self.assertEqual(reminder.remind_at, original_remind_at + datetime.timedelta(hours=1))

    def test_sends_normally_when_goal_not_yet_met(self):
        DailyLog.objects.create(user=self.user, date=timezone.localdate(), water_ml=100)
        reminder = self._due_reminder(metric=Reminder.Metric.WATER, skip_if_goal_met=True)

        call_command('send_due_reminders', stdout=StringIO())

        reminder.refresh_from_db()
        self.assertEqual(len(mail.outbox), 1)
        self.assertIsNotNone(reminder.last_sent_at)

    def test_one_off_reminder_skipped_for_met_goal_still_deactivates(self):
        DailyLog.objects.create(user=self.user, date=timezone.localdate(), water_ml=3000)
        reminder = self._due_reminder(
            repeat=Reminder.Repeat.NONE, metric=Reminder.Metric.WATER, skip_if_goal_met=True,
        )

        call_command('send_due_reminders', stdout=StringIO())

        reminder.refresh_from_db()
        self.assertEqual(len(mail.outbox), 0)
        self.assertFalse(reminder.is_active)
        self.assertIsNone(reminder.last_sent_at)


class ReminderFormValidationTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ana', password='pw')

    def test_skip_if_goal_met_requires_a_metric(self):
        from .forms import ReminderForm

        form = ReminderForm(data={
            'title': 'Drink water',
            'remind_at': timezone.localtime().strftime('%Y-%m-%dT%H:%M'),
            'repeat': Reminder.Repeat.HOURLY,
            'is_active': True,
            'metric': Reminder.Metric.NONE,
            'skip_if_goal_met': True,
        })
        self.assertFalse(form.is_valid())
        self.assertIn('skip_if_goal_met', form.errors)
