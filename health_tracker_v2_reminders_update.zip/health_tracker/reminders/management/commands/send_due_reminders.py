from django.core.mail import send_mail
from django.core.management.base import BaseCommand
from django.utils import timezone

from accounts.models import Profile
from reminders.models import Reminder
from reminders.services import is_metric_goal_met


class Command(BaseCommand):
    """Send (or simulate sending) any reminders that are due.

    This does not schedule itself — it's meant to be invoked periodically
    by an external scheduler (cron on Linux/macOS, Task Scheduler on
    Windows, or a hosting platform's scheduled-job feature), e.g. every
    five minutes:

        python manage.py send_due_reminders

    With the default console email backend this just prints the email to
    the terminal running the dev server. Point MAILERS['default'] at a
    real backend (SMTP, etc.) in settings.py to send real emails.

    Two things can silently suppress a due reminder instead of sending it
    (the reminder is still rescheduled as usual, so it doesn't pile up):
      - Quiet hours: an HOURLY reminder due during the user's configured
        quiet-hours window (see Profile.quiet_hours_start/end).
      - Goal already met: a reminder with skip_if_goal_met=True whose
        linked metric has already hit today's target.
    """

    help = 'Send any active reminders whose remind_at time has passed.'

    def handle(self, *args, **options):
        due = list(Reminder.objects.filter(
            is_active=True,
            remind_at__lte=timezone.now(),
        ).select_related('user'))

        profiles_by_user_id = {
            profile.user_id: profile
            for profile in Profile.objects.filter(user_id__in=[r.user_id for r in due])
        }

        sent_count = 0
        skipped_count = 0
        for reminder in due:
            profile = profiles_by_user_id.get(reminder.user_id)

            in_quiet_hours = (
                reminder.repeat == Reminder.Repeat.HOURLY
                and profile is not None
                and profile.is_within_quiet_hours(timezone.now())
            )
            goal_already_met = (
                reminder.skip_if_goal_met
                and reminder.metric != Reminder.Metric.NONE
                and is_metric_goal_met(reminder.user, reminder.metric)
            )

            if in_quiet_hours or goal_already_met:
                skipped_count += 1
                reminder.advance_after_send(sent=False)
                continue

            recipient = reminder.user.email
            if recipient:
                send_mail(
                    subject=f'Reminder: {reminder.title}',
                    message=reminder.message or 'This is your scheduled reminder.',
                    from_email=None,
                    recipient_list=[recipient],
                    fail_silently=True,
                )
                sent_count += 1
            reminder.advance_after_send(sent=True)

        self.stdout.write(self.style.SUCCESS(
            f'Processed {len(due)} due reminder(s), emailed {sent_count}, skipped {skipped_count}.'
        ))
