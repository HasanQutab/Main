import csv
import json

from django.contrib import messages
from django.http import HttpResponse, HttpResponseBadRequest, JsonResponse
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError, transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import DailyLogForm
from .models import DailyLog
from .recommendations import get_profile_for_user, get_recommended_targets, percent_of


@login_required
def log_list(request):
    logs = DailyLog.objects.filter(user=request.user)

    # Optional date-range filter (Phase 8)
    date_from = request.GET.get('from', '')
    date_to = request.GET.get('to', '')
    if date_from:
        logs = logs.filter(date__gte=date_from)
    if date_to:
        logs = logs.filter(date__lte=date_to)

    today_log = DailyLog.objects.filter(user=request.user, date=timezone.localdate()).first()

    # Chart data: last 30 entries in chronological order (Phase 8)
    chart_logs = list(
        DailyLog.objects.filter(user=request.user).order_by('-date')[:30]
    )
    chart_logs.reverse()

    targets = get_recommended_targets(get_profile_for_user(request.user))

    return render(request, 'health/list.html', {
        'logs': logs[:30],
        'today_log': today_log,
        'steps_goal': targets['steps'],
        'water_goal': targets['water_ml'],
        'sleep_goal': targets['sleep_hours'],
        'steps_percent': percent_of(today_log.steps if today_log else 0, targets['steps']),
        'water_percent': percent_of(today_log.water_ml if today_log else 0, targets['water_ml']),
        'sleep_percent': percent_of(today_log.sleep_hours if today_log else 0, targets['sleep_hours']),
        'targets': targets,
        'date_from': date_from,
        'date_to': date_to,
        'chart_dates': [log.date.isoformat() for log in chart_logs],
        'chart_steps': [log.steps or 0 for log in chart_logs],
        'chart_sleep': [float(log.sleep_hours) if log.sleep_hours else 0 for log in chart_logs],
    })


@login_required
def log_create(request):
    if request.method == 'POST':
        form = DailyLogForm(request.POST)
        if form.is_valid():
            log = form.save(commit=False)
            log.user = request.user
            try:
                with transaction.atomic():
                    log.save()
            except IntegrityError:
                form.add_error('date', 'You already have an entry for this date. Edit it instead.')
            else:
                messages.success(request, 'Entry logged.')
                return redirect('health:list')
    else:
        form = DailyLogForm(initial={'date': timezone.localdate()})

    return render(request, 'health/form.html', {'form': form, 'is_edit': False})


@login_required
def log_edit(request, pk):
    log = get_object_or_404(DailyLog, pk=pk, user=request.user)
    if request.method == 'POST':
        form = DailyLogForm(request.POST, instance=log)
        if form.is_valid():
            try:
                with transaction.atomic():
                    form.save()
            except IntegrityError:
                form.add_error('date', 'You already have an entry for this date.')
            else:
                messages.success(request, 'Entry updated.')
                return redirect('health:list')
    else:
        form = DailyLogForm(instance=log)

    return render(request, 'health/form.html', {'form': form, 'is_edit': True})


@login_required
def log_delete(request, pk):
    log = get_object_or_404(DailyLog, pk=pk, user=request.user)
    if request.method == 'POST':
        log.delete()
        messages.success(request, 'Entry deleted.')
        return redirect('health:list')
    return render(request, 'health/confirm_delete.html', {'log': log})


@login_required
def log_export(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="health_logs.csv"'

    writer = csv.writer(response)
    writer.writerow(['Date', 'Steps', 'Water (ml)', 'Sleep (hours)', 'Resting HR (bpm)', 'Notes'])
    for log in DailyLog.objects.filter(user=request.user):
        writer.writerow([log.date, log.steps, log.water_ml, log.sleep_hours, log.resting_heart_rate, log.notes])

    return response


def _read_json_body(request):
    try:
        return json.loads(request.body or '{}')
    except (ValueError, TypeError):
        return None


@login_required
@require_POST
def track_steps(request):
    """Adds device-counted steps (from the in-browser pedometer) onto
    today's log. Called repeatedly with small increments while tracking
    is active, so this always adds rather than overwrites."""
    payload = _read_json_body(request)
    if payload is None:
        return HttpResponseBadRequest('Invalid JSON body.')
    try:
        increment = int(payload.get('increment', 0))
    except (TypeError, ValueError):
        return HttpResponseBadRequest('increment must be an integer.')
    if increment <= 0:
        return HttpResponseBadRequest('increment must be positive.')

    today = timezone.localdate()
    log, _ = DailyLog.objects.get_or_create(user=request.user, date=today)
    log.steps = (log.steps or 0) + increment
    log.save(update_fields=['steps', 'updated_at'])

    targets = get_recommended_targets(get_profile_for_user(request.user))
    return JsonResponse({
        'steps': log.steps,
        'goal': targets['steps'],
        'percent': percent_of(log.steps, targets['steps']),
    })


@login_required
@require_POST
def track_water(request):
    """Adds a quick water top-up (from the hourly reminder widget or the
    dashboard) onto today's log."""
    payload = _read_json_body(request)
    if payload is None:
        return HttpResponseBadRequest('Invalid JSON body.')
    try:
        increment_ml = int(payload.get('increment_ml', 0))
    except (TypeError, ValueError):
        return HttpResponseBadRequest('increment_ml must be an integer.')
    if increment_ml <= 0:
        return HttpResponseBadRequest('increment_ml must be positive.')

    today = timezone.localdate()
    log, _ = DailyLog.objects.get_or_create(user=request.user, date=today)
    log.water_ml = (log.water_ml or 0) + increment_ml
    log.save(update_fields=['water_ml', 'updated_at'])

    targets = get_recommended_targets(get_profile_for_user(request.user))
    return JsonResponse({
        'water_ml': log.water_ml,
        'goal_ml': targets['water_ml'],
        'percent': percent_of(log.water_ml, targets['water_ml']),
    })
