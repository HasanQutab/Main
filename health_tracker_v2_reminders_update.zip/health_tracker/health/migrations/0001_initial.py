import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='DailyLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField()),
                ('steps', models.PositiveIntegerField(blank=True, null=True)),
                ('water_ml', models.PositiveIntegerField(blank=True, help_text='Water intake in milliliters.', null=True)),
                ('sleep_hours', models.DecimalField(blank=True, decimal_places=1, max_digits=4, null=True)),
                ('resting_heart_rate', models.PositiveIntegerField(blank=True, help_text='Resting heart rate in bpm.', null=True)),
                ('notes', models.CharField(blank=True, max_length=255)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='health_logs', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'ordering': ('-date',),
            },
        ),
        migrations.AddConstraint(
            model_name='dailylog',
            constraint=models.UniqueConstraint(fields=('user', 'date'), name='unique_health_log_per_day'),
        ),
    ]
