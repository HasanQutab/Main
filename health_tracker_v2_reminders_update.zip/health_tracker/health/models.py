from django.conf import settings
from django.db import models

# Simple defaults used to compute "% of daily goal" on dashboard cards.
# These are not user-configurable yet; per-user targets can be layered on
# top of this later without changing the schema.
DEFAULT_STEPS_GOAL = 10000
DEFAULT_WATER_GOAL_ML = 2000
DEFAULT_SLEEP_GOAL_HOURS = 8


class DailyLog(models.Model):
    """One entry per user per day capturing the core health metrics."""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='health_logs',
    )
    date = models.DateField()
    steps = models.PositiveIntegerField(null=True, blank=True)
    water_ml = models.PositiveIntegerField(
        null=True, blank=True, help_text='Water intake in milliliters.',
    )
    sleep_hours = models.DecimalField(
        max_digits=4, decimal_places=1, null=True, blank=True,
    )
    resting_heart_rate = models.PositiveIntegerField(
        null=True, blank=True, help_text='Resting heart rate in bpm.',
    )
    notes = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ('-date',)
        constraints = [
            models.UniqueConstraint(fields=('user', 'date'), name='unique_health_log_per_day'),
        ]

    def __str__(self):
        return f'{self.user.username} — {self.date}'

    @property
    def steps_goal_percent(self):
        if not self.steps:
            return 0
        return min(round(self.steps / DEFAULT_STEPS_GOAL * 100), 100)

    @property
    def water_goal_percent(self):
        if not self.water_ml:
            return 0
        return min(round(self.water_ml / DEFAULT_WATER_GOAL_ML * 100), 100)

    @property
    def sleep_goal_percent(self):
        if not self.sleep_hours:
            return 0
        return min(round(float(self.sleep_hours) / DEFAULT_SLEEP_GOAL_HOURS * 100), 100)
