from django import forms

from .models import DailyLog


class DailyLogForm(forms.ModelForm):
    class Meta:
        model = DailyLog
        fields = ('date', 'steps', 'water_ml', 'sleep_hours', 'resting_heart_rate', 'notes')
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
        }
