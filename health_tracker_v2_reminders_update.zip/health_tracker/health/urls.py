from django.urls import path

from . import views

app_name = 'health'

urlpatterns = [
    path('health/', views.log_list, name='list'),
    path('health/log/', views.log_create, name='create'),
    path('health/<int:pk>/edit/', views.log_edit, name='edit'),
    path('health/<int:pk>/delete/', views.log_delete, name='delete'),
    path('health/export/', views.log_export, name='export'),
    path('health/track/steps/', views.track_steps, name='track_steps'),
    path('health/track/water/', views.track_water, name='track_water'),
]
