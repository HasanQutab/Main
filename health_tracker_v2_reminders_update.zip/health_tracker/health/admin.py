from django.contrib import admin

from .models import DailyLog


@admin.register(DailyLog)
class DailyLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'date', 'steps', 'water_ml', 'sleep_hours', 'resting_heart_rate')
    list_filter = ('date',)
    search_fields = ('user__username',)
