"""Personalized health targets.

Turns a user's profile (age from date_of_birth, weight_kg) into recommended
daily targets for steps, water, and sleep. These are general wellness
guidelines, not medical advice, and are used only to personalize the
existing goal displays — they never block logging any value.
"""
from datetime import date

from accounts.models import Profile

from .models import (
    DEFAULT_SLEEP_GOAL_HOURS,
    DEFAULT_STEPS_GOAL,
    DEFAULT_WATER_GOAL_ML,
)


def _age_from_dob(dob):
    if not dob:
        return None
    today = date.today()
    had_birthday = (today.month, today.day) >= (dob.month, dob.day)
    return today.year - dob.year - (0 if had_birthday else 1)


def get_profile_for_user(user):
    """Look up a user's Profile without creating one (safe for views that
    aren't the profile page itself)."""
    if not user or not user.is_authenticated:
        return None
    return Profile.objects.filter(user=user).first()


def get_recommended_targets(profile):
    """Return {'age', 'steps', 'water_ml', 'sleep_hours'} for the given
    Profile (or None). Falls back to general adult defaults when age or
    weight aren't on file yet."""
    age = _age_from_dob(getattr(profile, 'date_of_birth', None)) if profile else None
    weight_kg = float(profile.weight_kg) if profile and profile.weight_kg else None

    if age is None:
        steps_goal = DEFAULT_STEPS_GOAL
        sleep_goal = DEFAULT_SLEEP_GOAL_HOURS
    elif age < 13:
        steps_goal, sleep_goal = 12000, 10.0
    elif age < 18:
        steps_goal, sleep_goal = 11000, 9.0
    elif age < 40:
        steps_goal, sleep_goal = 10000, 8.0
    elif age < 60:
        steps_goal, sleep_goal = 8000, 7.5
    else:
        steps_goal, sleep_goal = 7000, 7.5

    if weight_kg:
        # ~35ml per kg of body weight is a common general-wellness rule of
        # thumb, rounded to the nearest 50ml and clamped to a sane range.
        water_goal = round((weight_kg * 35) / 50) * 50
        water_goal = max(1500, min(water_goal, 4000))
    elif age is not None and age < 18:
        water_goal = 1900
    else:
        water_goal = DEFAULT_WATER_GOAL_ML

    return {
        'age': age,
        'steps': steps_goal,
        'water_ml': water_goal,
        'sleep_hours': sleep_goal,
        'personalized': age is not None,
    }


def percent_of(value, goal):
    if not value or not goal:
        return 0
    return max(0, min(round(float(value) / float(goal) * 100), 100))
