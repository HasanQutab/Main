from rest_framework import permissions, viewsets

from goals import services as goal_services
from goals.models import Goal
from habits.models import Habit, HabitLog
from health.models import DailyLog
from reminders.models import Reminder

from .serializers import (
    DailyLogSerializer,
    GoalSerializer,
    HabitLogSerializer,
    HabitSerializer,
    ReminderSerializer,
)


class UserScopedModelViewSet(viewsets.ModelViewSet):
    """Base viewset that scopes every query to request.user and stamps new
    objects with request.user automatically."""

    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return self.queryset.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class DailyLogViewSet(UserScopedModelViewSet):
    queryset = DailyLog.objects.all()
    serializer_class = DailyLogSerializer


class HabitViewSet(UserScopedModelViewSet):
    queryset = Habit.objects.all()
    serializer_class = HabitSerializer


class HabitLogViewSet(viewsets.ModelViewSet):
    """Flat endpoint; each log references its habit by id in the payload.
    Scoped so a user can only see/create logs for their own habits."""

    serializer_class = HabitLogSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return HabitLog.objects.filter(habit__user=self.request.user)


class GoalViewSet(UserScopedModelViewSet):
    queryset = Goal.objects.all()
    serializer_class = GoalSerializer

    def perform_create(self, serializer):
        goal = serializer.save(user=self.request.user)
        if goal.auto_track:
            goal_services.sync_goal(goal)

    def perform_update(self, serializer):
        goal = serializer.save()
        if goal.auto_track:
            goal_services.sync_goal(goal)


class ReminderViewSet(UserScopedModelViewSet):
    queryset = Reminder.objects.all()
    serializer_class = ReminderSerializer
