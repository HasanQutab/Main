from rest_framework.routers import DefaultRouter

from . import views

app_name = 'api'

router = DefaultRouter()
router.register('health-logs', views.DailyLogViewSet, basename='healthlog')
router.register('habits', views.HabitViewSet, basename='habit')
router.register('habit-logs', views.HabitLogViewSet, basename='habitlog')
router.register('goals', views.GoalViewSet, basename='goal')
router.register('reminders', views.ReminderViewSet, basename='reminder')

urlpatterns = router.urls
