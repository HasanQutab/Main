from rest_framework import serializers

from goals.models import Goal
from habits.models import Habit, HabitLog
from health.models import DailyLog
from reminders.models import Reminder


class DailyLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = DailyLog
        fields = (
            'id', 'date', 'steps', 'water_ml', 'sleep_hours',
            'resting_heart_rate', 'notes', 'created_at', 'updated_at',
        )
        read_only_fields = ('id', 'created_at', 'updated_at')


class HabitLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = HabitLog
        fields = ('id', 'habit', 'date', 'completed', 'created_at')
        read_only_fields = ('id', 'created_at')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        request = self.context.get('request')
        if request is not None:
            self.fields['habit'].queryset = Habit.objects.filter(user=request.user)


class HabitSerializer(serializers.ModelSerializer):
    current_streak = serializers.SerializerMethodField()

    class Meta:
        model = Habit
        fields = ('id', 'name', 'description', 'is_active', 'current_streak', 'created_at')
        read_only_fields = ('id', 'created_at')

    def get_current_streak(self, obj):
        return obj.current_streak()


class GoalSerializer(serializers.ModelSerializer):
    progress_percent = serializers.ReadOnlyField()

    class Meta:
        model = Goal
        fields = (
            'id', 'title', 'category', 'target_value', 'current_value',
            'unit', 'deadline', 'is_achieved', 'auto_track', 'progress_percent', 'created_at',
        )
        read_only_fields = ('id', 'is_achieved', 'progress_percent', 'created_at')

    def validate(self, attrs):
        auto_track = attrs.get('auto_track', getattr(self.instance, 'auto_track', False))
        category = attrs.get('category', getattr(self.instance, 'category', None))
        if auto_track and category not in Goal.AUTO_TRACKABLE_CATEGORIES:
            raise serializers.ValidationError({
                'auto_track': 'Auto-tracking is only available for steps, water, sleep, or weight goals.',
            })
        # Auto-tracked goals get their current_value from health data only —
        # block clients from overwriting it directly, same as the web UI.
        if auto_track and 'current_value' in attrs and self.instance is not None:
            attrs.pop('current_value')
        return attrs


class ReminderSerializer(serializers.ModelSerializer):
    is_past_due = serializers.ReadOnlyField()

    class Meta:
        model = Reminder
        fields = (
            'id', 'title', 'message', 'remind_at', 'repeat', 'metric', 'skip_if_goal_met',
            'is_active', 'is_past_due', 'last_sent_at', 'created_at',
        )
        read_only_fields = ('id', 'is_past_due', 'last_sent_at', 'created_at')

    def validate(self, attrs):
        metric = attrs.get('metric', getattr(self.instance, 'metric', Reminder.Metric.NONE))
        skip_if_goal_met = attrs.get('skip_if_goal_met', getattr(self.instance, 'skip_if_goal_met', False))
        if skip_if_goal_met and metric in (None, '', Reminder.Metric.NONE):
            raise serializers.ValidationError({
                'skip_if_goal_met': 'Link this reminder to a metric (steps, water, or sleep) to skip it when the goal is met.',
            })
        return attrs
