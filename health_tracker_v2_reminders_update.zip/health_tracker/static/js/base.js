// Shared JavaScript for the Health Tracker app.
// Habit toggles, health logging, and goal progress updates are handled
// with plain form submissions (no JS required) through Phase 5.

document.addEventListener("DOMContentLoaded", function () {
    // Sticky topbar gains a shadow once the page scrolls.
    var topbar = document.getElementById("topbar");
    if (topbar) {
        var onScroll = function () {
            topbar.classList.toggle("is-scrolled", window.scrollY > 4);
        };
        onScroll();
        window.addEventListener("scroll", onScroll, { passive: true });
    }

    // Staggered fade/rise-in for the main content blocks.
    var targets = document.querySelectorAll(
        ".card, .step-hero, .auth-card, .empty-state"
    );

    if (!targets.length) {
        return;
    }

    var prefersReducedMotion = window.matchMedia(
        "(prefers-reduced-motion: reduce)"
    ).matches;

    if (prefersReducedMotion || typeof IntersectionObserver === "undefined") {
        return;
    }

    targets.forEach(function (el, index) {
        el.classList.add("reveal");
        el.style.transitionDelay = Math.min(index * 60, 240) + "ms";
    });

    var observer = new IntersectionObserver(
        function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add("is-visible");
                    observer.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
    );

    targets.forEach(function (el) {
        observer.observe(el);
    });
});
