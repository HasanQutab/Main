// In-browser step counter (via the device accelerometer) and an
// hourly water-drinking reminder. Both are best-effort: step counting
// needs a phone with motion sensors and a permission grant, and the
// water reminder only fires while a tab from this app is open.
(function () {
    "use strict";

    var configEl = document.getElementById("tracker-config");
    if (!configEl) {
        return;
    }
    var config = JSON.parse(configEl.textContent);

    function getCookie(name) {
        var match = document.cookie.match(
            new RegExp("(^| )" + name + "=([^;]+)")
        );
        return match ? decodeURIComponent(match[2]) : null;
    }

    function postJson(url, body) {
        return fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": getCookie("csrftoken") || "",
            },
            body: JSON.stringify(body),
            credentials: "same-origin",
        }).then(function (res) {
            if (!res.ok) {
                throw new Error("Request failed: " + res.status);
            }
            return res.json();
        });
    }

    function updateStepDisplays(data) {
        document.querySelectorAll("#live-step-count").forEach(function (el) {
            el.textContent = data.steps;
        });
        var ringFill = document.querySelector(".step-ring__fill");
        if (ringFill && typeof data.percent === "number") {
            ringFill.style.setProperty("--step-percent", data.percent);
        }
        document.querySelectorAll(".progress-fill").forEach(function (el) {
            // Only touch the steps progress bar, identified by proximity
            // to a live-step-count element in the same card.
            var card = el.closest(".card");
            if (card && card.querySelector("#live-step-count")) {
                el.style.width = data.percent + "%";
            }
        });
    }

    function updateWaterDisplays(data) {
        document.querySelectorAll("#live-water-ml").forEach(function (el) {
            el.textContent = data.water_ml + " ml";
        });
        document.querySelectorAll(".progress-fill").forEach(function (el) {
            var card = el.closest(".card");
            if (card && card.querySelector("#live-water-ml")) {
                el.style.width = data.percent + "%";
            }
        });
    }

    /* -------------------------------------------------------------
       Pedometer
       ------------------------------------------------------------- */
    var STORAGE_ACTIVE = "healthTracker.pedometerActive";
    var pendingSteps = 0;
    var lastStepAt = 0;
    var gravityEstimate = null;
    var listening = false;

    // Simple peak-detection step counter over the acceleration magnitude:
    // a step shows up as a sharp rise above a rolling "gravity" baseline,
    // gated by a minimum interval so a single footfall isn't double-counted.
    function handleMotion(event) {
        var acc = event.accelerationIncludingGravity;
        if (!acc || acc.x === null) {
            return;
        }
        var magnitude = Math.sqrt(
            (acc.x || 0) * (acc.x || 0) +
                (acc.y || 0) * (acc.y || 0) +
                (acc.z || 0) * (acc.z || 0)
        );

        if (gravityEstimate === null) {
            gravityEstimate = magnitude;
            return;
        }
        // Slow-moving baseline so it tracks device orientation, not steps.
        gravityEstimate += (magnitude - gravityEstimate) * 0.05;

        var delta = magnitude - gravityEstimate;
        var now = Date.now();
        var THRESHOLD = 3.2; // m/s^2 above baseline
        var MIN_INTERVAL_MS = 300; // fastest plausible step cadence

        if (delta > THRESHOLD && now - lastStepAt > MIN_INTERVAL_MS) {
            lastStepAt = now;
            pendingSteps += 1;
        }
    }

    function flushSteps() {
        if (pendingSteps <= 0) {
            return;
        }
        var toSend = pendingSteps;
        pendingSteps = 0;
        postJson(config.trackStepsUrl, { increment: toSend })
            .then(updateStepDisplays)
            .catch(function () {
                // Retry next flush rather than losing the count.
                pendingSteps += toSend;
            });
    }

    function setToggleLabel(active) {
        document.querySelectorAll("#pedometer-toggle").forEach(function (btn) {
            btn.textContent = active ? "Stop step tracking" : "Start step tracking";
            btn.classList.toggle("btn--primary", active);
            btn.classList.toggle("btn--secondary", !active);
        });
    }

    function startTracking() {
        if (listening || typeof DeviceMotionEvent === "undefined") {
            return;
        }
        var begin = function () {
            window.addEventListener("devicemotion", handleMotion);
            listening = true;
            localStorage.setItem(STORAGE_ACTIVE, "1");
            setToggleLabel(true);
        };

        if (typeof DeviceMotionEvent.requestPermission === "function") {
            DeviceMotionEvent.requestPermission()
                .then(function (permission) {
                    if (permission === "granted") {
                        begin();
                    } else {
                        alert("Motion access was declined, so steps can't be counted on this device.");
                    }
                })
                .catch(function () {
                    alert("Couldn't request motion access on this device.");
                });
        } else {
            begin();
        }
    }

    function stopTracking() {
        window.removeEventListener("devicemotion", handleMotion);
        listening = false;
        localStorage.setItem(STORAGE_ACTIVE, "0");
        setToggleLabel(false);
        flushSteps();
    }

    document.querySelectorAll("#pedometer-toggle").forEach(function (btn) {
        btn.addEventListener("click", function () {
            if (listening) {
                stopTracking();
            } else {
                startTracking();
            }
        });
    });

    // Resume tracking automatically if it was left on when the user
    // navigated to a new page.
    if (
        localStorage.getItem(STORAGE_ACTIVE) === "1" &&
        typeof DeviceMotionEvent !== "undefined" &&
        typeof DeviceMotionEvent.requestPermission !== "function"
    ) {
        // Only auto-resume where no explicit permission prompt is needed
        // (Android/desktop). iOS requires a fresh user gesture each time.
        startTracking();
    } else if (localStorage.getItem(STORAGE_ACTIVE) === "1") {
        setToggleLabel(false);
        localStorage.setItem(STORAGE_ACTIVE, "0");
    }

    if (typeof DeviceMotionEvent === "undefined") {
        document.querySelectorAll("#pedometer-toggle").forEach(function (btn) {
            btn.disabled = true;
            btn.title = "This device/browser doesn't expose motion sensors.";
        });
    }

    setInterval(flushSteps, 15000);
    window.addEventListener("beforeunload", flushSteps);
    document.addEventListener("visibilitychange", function () {
        if (document.hidden) {
            flushSteps();
        }
    });

    /* -------------------------------------------------------------
       Hourly water reminder
       ------------------------------------------------------------- */
    var STORAGE_NEXT_REMINDER = "healthTracker.nextWaterReminderAt";
    var intervalMs = config.reminderIntervalMs || 3600000;
    var toast = document.getElementById("water-reminder-toast");

    function scheduleNextReminder() {
        localStorage.setItem(STORAGE_NEXT_REMINDER, String(Date.now() + intervalMs));
    }

    function showWaterToast() {
        if (!toast) {
            return;
        }
        toast.hidden = false;
        if (window.Notification && Notification.permission === "granted" && document.hidden) {
            try {
                new Notification("Time to drink water", {
                    body: "It's been an hour — a quick top-up keeps you on track.",
                });
            } catch (err) {
                /* Notifications aren't critical; ignore failures. */
            }
        }
    }

    function checkWaterReminder() {
        var next = parseInt(localStorage.getItem(STORAGE_NEXT_REMINDER) || "0", 10);
        if (!next) {
            scheduleNextReminder();
            return;
        }
        if (Date.now() >= next) {
            showWaterToast();
            scheduleNextReminder();
        }
    }

    if (toast) {
        var logBtn = document.getElementById("water-toast-log");
        var dismissBtn = document.getElementById("water-toast-dismiss");

        if (logBtn) {
            logBtn.addEventListener("click", function () {
                postJson(config.trackWaterUrl, { increment_ml: 250 })
                    .then(updateWaterDisplays)
                    .finally(function () {
                        toast.hidden = true;
                    });
            });
        }
        if (dismissBtn) {
            dismissBtn.addEventListener("click", function () {
                toast.hidden = true;
            });
        }

        if (window.Notification && Notification.permission === "default") {
            // Best-effort, silent request — never blocks the UI on refusal.
            Notification.requestPermission().catch(function () {});
        }
    }

    checkWaterReminder();
    setInterval(checkWaterReminder, 30000);

    document.querySelectorAll("[data-water-add]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var amount = parseInt(btn.getAttribute("data-water-add"), 10) || 0;
            if (amount <= 0) {
                return;
            }
            postJson(config.trackWaterUrl, { increment_ml: amount }).then(updateWaterDisplays);
        });
    });
})();
