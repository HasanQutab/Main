from django.urls import path

from . import views

app_name = 'goals'

urlpatterns = [
    path('goals/', views.goal_list, name='list'),
    path('goals/new/', views.goal_create, name='create'),
    path('goals/<int:pk>/edit/', views.goal_edit, name='edit'),
    path('goals/<int:pk>/delete/', views.goal_delete, name='delete'),
    path('goals/<int:pk>/progress/', views.goal_update_progress, name='progress'),
    path('goals/export/', views.goal_export, name='export'),
]
