from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver

from . import services


@receiver(post_save, sender='health.DailyLog', dispatch_uid='goals_sync_on_daily_log_save')
def sync_goals_on_daily_log_save(sender, instance, **kwargs):
    services.sync_health_goals(instance.user)


@receiver(post_delete, sender='health.DailyLog', dispatch_uid='goals_sync_on_daily_log_delete')
def sync_goals_on_daily_log_delete(sender, instance, **kwargs):
    # A log's values disappear with it, so recompute from whatever's left.
    services.sync_health_goals(instance.user)


@receiver(post_save, sender='accounts.Profile', dispatch_uid='goals_sync_on_profile_save')
def sync_goals_on_profile_save(sender, instance, **kwargs):
    services.sync_weight_goals(instance.user, instance.weight_kg)
