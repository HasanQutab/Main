from django.contrib import admin

from .models import Goal


@admin.register(Goal)
class GoalAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'category', 'current_value', 'target_value', 'is_achieved', 'deadline')
    list_filter = ('category', 'is_achieved')
    search_fields = ('title', 'user__username')
