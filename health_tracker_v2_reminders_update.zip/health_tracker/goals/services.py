"""Keeps auto-tracked Goals in sync with the data that backs them.

Steps / water / sleep goals mirror the most recent DailyLog entry that has a
value for that field. Weight goals mirror Profile.weight_kg. Nothing here
touches goals with auto_track=False — those stay fully manual.
"""
from .models import Goal

# Maps a Goal category onto the DailyLog field it should track.
_HEALTH_LOG_FIELDS = {
    Goal.Category.STEPS: 'steps',
    Goal.Category.WATER: 'water_ml',
    Goal.Category.SLEEP: 'sleep_hours',
}


def _latest_log_value(user, field_name):
    """Most recent (by date) DailyLog value for `field_name` that isn't
    null, or None if the user has no such entries at all."""
    from health.models import DailyLog

    log = (
        DailyLog.objects.filter(user=user, **{f'{field_name}__isnull': False})
        .order_by('-date', '-id')
        .first()
    )
    return getattr(log, field_name) if log else None


def sync_health_goals(user, categories=None):
    """Recompute current_value for the user's auto-tracked steps/water/sleep
    goals. Pass `categories` to limit the work (e.g. to just the field that
    changed); defaults to all three.

    Falls back to 0 when there's no matching log data at all, so a newly
    auto-tracked goal — or one whose only log was deleted — reads as "no
    progress yet" rather than keeping a stale number.
    """
    categories = categories or list(_HEALTH_LOG_FIELDS)
    goals = Goal.objects.filter(user=user, auto_track=True, category__in=categories)
    for goal in goals:
        field_name = _HEALTH_LOG_FIELDS.get(goal.category)
        if not field_name:
            continue
        value = _latest_log_value(user, field_name)
        goal.apply_auto_value(value or 0)


def sync_weight_goals(user, weight_kg):
    """Recompute current_value for the user's auto-tracked weight goals from
    their profile. Unlike sync_health_goals, a missing weight_kg is left
    alone rather than zeroed — an empty profile field shouldn't wipe out a
    goal's progress before the user has ever recorded a weight."""
    if weight_kg is None:
        return
    goals = Goal.objects.filter(user=user, auto_track=True, category=Goal.Category.WEIGHT)
    for goal in goals:
        goal.apply_auto_value(weight_kg)


def sync_goal(goal):
    """Sync a single goal right away — used right after a goal is created
    or edited with auto_track turned on, so it doesn't sit at its old/blank
    value until the next health log or profile save."""
    if not goal.auto_track:
        return
    if goal.category == Goal.Category.WEIGHT:
        from accounts.models import Profile

        profile = Profile.objects.filter(user=goal.user).first()
        if profile and profile.weight_kg is not None:
            goal.apply_auto_value(profile.weight_kg)
    else:
        field_name = _HEALTH_LOG_FIELDS.get(goal.category)
        if field_name:
            value = _latest_log_value(goal.user, field_name)
            goal.apply_auto_value(value or 0)
