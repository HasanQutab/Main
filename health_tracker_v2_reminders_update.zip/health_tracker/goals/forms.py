from django import forms

from .models import Goal


class GoalForm(forms.ModelForm):
    class Meta:
        model = Goal
        fields = ('title', 'category', 'target_value', 'current_value', 'unit', 'deadline', 'auto_track')
        widgets = {
            'deadline': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
        }

    def clean(self):
        cleaned_data = super().clean()
        category = cleaned_data.get('category')
        auto_track = cleaned_data.get('auto_track')
        if auto_track and category not in Goal.AUTO_TRACKABLE_CATEGORIES:
            self.add_error(
                'auto_track',
                'Auto-tracking is only available for steps, water, sleep, or weight goals.',
            )
        return cleaned_data
