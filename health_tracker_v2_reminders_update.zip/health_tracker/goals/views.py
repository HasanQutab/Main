import csv
from decimal import Decimal, InvalidOperation

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.core.exceptions import ValidationError
from django.shortcuts import get_object_or_404, redirect, render

from . import services
from .forms import GoalForm
from .models import Goal


@login_required
def goal_list(request):
    category = request.GET.get('category', '')

    goals = Goal.objects.filter(user=request.user)
    if category:
        goals = goals.filter(category=category)

    active_goals = goals.filter(is_achieved=False)
    achieved_goals = goals.filter(is_achieved=True)
    return render(request, 'goals/list.html', {
        'active_goals': active_goals,
        'achieved_goals': achieved_goals,
        'category': category,
        'category_choices': Goal.Category.choices,
    })


@login_required
def goal_create(request):
    if request.method == 'POST':
        form = GoalForm(request.POST)
        if form.is_valid():
            goal = form.save(commit=False)
            goal.user = request.user
            goal.save()
            if goal.auto_track:
                services.sync_goal(goal)
            messages.success(request, 'Goal created.')
            return redirect('goals:list')
    else:
        form = GoalForm()
    return render(request, 'goals/form.html', {'form': form, 'is_edit': False})


@login_required
def goal_edit(request, pk):
    goal = get_object_or_404(Goal, pk=pk, user=request.user)
    if request.method == 'POST':
        form = GoalForm(request.POST, instance=goal)
        if form.is_valid():
            goal = form.save()
            if goal.auto_track:
                services.sync_goal(goal)
            messages.success(request, 'Goal updated.')
            return redirect('goals:list')
    else:
        form = GoalForm(instance=goal)
    return render(request, 'goals/form.html', {'form': form, 'is_edit': True})


@login_required
def goal_delete(request, pk):
    goal = get_object_or_404(Goal, pk=pk, user=request.user)
    if request.method == 'POST':
        goal.delete()
        messages.success(request, 'Goal deleted.')
        return redirect('goals:list')
    return render(request, 'goals/confirm_delete.html', {'goal': goal})


@login_required
def goal_update_progress(request, pk):
    goal = get_object_or_404(Goal, pk=pk, user=request.user)
    if request.method == 'POST':
        if goal.auto_track:
            messages.error(request, 'This goal is auto-tracked and updates from your health logs.')
            return redirect('goals:list')
        value = request.POST.get('current_value', '')
        try:
            goal.current_value = Decimal(value)
            goal.full_clean()
        except (InvalidOperation, TypeError, ValidationError):
            messages.error(request, 'Enter a valid number.')
        else:
            goal.save()
            messages.success(request, 'Progress updated.')
    return redirect('goals:list')


@login_required
def goal_export(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="goals.csv"'

    writer = csv.writer(response)
    writer.writerow(['Title', 'Category', 'Current', 'Target', 'Unit', 'Deadline', 'Achieved'])
    for goal in Goal.objects.filter(user=request.user):
        writer.writerow([goal.title, goal.get_category_display(), goal.current_value, goal.target_value, goal.unit, goal.deadline, goal.is_achieved])

    return response
