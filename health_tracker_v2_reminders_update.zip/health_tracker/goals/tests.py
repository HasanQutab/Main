import datetime
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from accounts.models import Profile
from health.models import DailyLog

from .models import Goal

User = get_user_model()


class GoalAutoTrackModelTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ana', password='pw')

    def _make_goal(self, category, target=10000, auto_track=True):
        return Goal.objects.create(
            user=self.user,
            title=f'{category} goal',
            category=category,
            target_value=Decimal(str(target)),
            current_value=Decimal('0'),
            auto_track=auto_track,
        )

    def test_steps_goal_syncs_from_daily_log(self):
        goal = self._make_goal(Goal.Category.STEPS, target=10000)
        DailyLog.objects.create(user=self.user, date=datetime.date.today(), steps=6500)

        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('6500'))
        self.assertFalse(goal.is_achieved)

    def test_goal_marked_achieved_when_synced_value_meets_target(self):
        goal = self._make_goal(Goal.Category.STEPS, target=10000)
        DailyLog.objects.create(user=self.user, date=datetime.date.today(), steps=12000)

        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('12000'))
        self.assertTrue(goal.is_achieved)

    def test_uses_most_recent_log_by_date_not_save_order(self):
        goal = self._make_goal(Goal.Category.WATER, target=2000)
        DailyLog.objects.create(user=self.user, date=datetime.date.today(), water_ml=1500)
        DailyLog.objects.create(
            user=self.user, date=datetime.date.today() - datetime.timedelta(days=1), water_ml=3000,
        )

        goal.refresh_from_db()
        # Today's entry is more recent even though the older one has a
        # bigger number, so today's value should win.
        self.assertEqual(goal.current_value, Decimal('1500'))

    def test_manually_tracked_goal_is_not_touched_by_logs(self):
        goal = self._make_goal(Goal.Category.STEPS, target=10000, auto_track=False)
        DailyLog.objects.create(user=self.user, date=datetime.date.today(), steps=9999)

        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('0'))

    def test_weight_goal_syncs_from_profile(self):
        goal = self._make_goal(Goal.Category.WEIGHT, target=70)
        profile = Profile.objects.create(user=self.user, weight_kg=Decimal('75.0'))
        profile.weight_kg = Decimal('72.5')
        profile.save()

        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('72.5'))

    def test_deleting_only_log_resets_auto_tracked_value_to_zero(self):
        goal = self._make_goal(Goal.Category.SLEEP, target=8)
        log = DailyLog.objects.create(user=self.user, date=datetime.date.today(), sleep_hours=Decimal('7.5'))
        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('7.5'))

        log.delete()
        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('0'))

    def test_enabling_auto_track_on_edit_syncs_immediately(self):
        goal = self._make_goal(Goal.Category.STEPS, target=10000, auto_track=False)
        DailyLog.objects.create(user=self.user, date=datetime.date.today(), steps=4000)
        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('0'))  # untouched while manual

        goal.auto_track = True
        goal.save()
        from . import services
        services.sync_goal(goal)
        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('4000'))


class GoalAutoTrackViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ana', password='pw')
        self.client.login(username='ana', password='pw')

    def test_creating_auto_track_goal_syncs_value_immediately(self):
        DailyLog.objects.create(user=self.user, date=datetime.date.today(), steps=8000)

        response = self.client.post(reverse('goals:create'), {
            'title': 'Hit steps',
            'category': Goal.Category.STEPS,
            'target_value': '10000',
            'current_value': '0',
            'unit': 'steps',
            'auto_track': 'on',
        })
        self.assertEqual(response.status_code, 302)

        goal = Goal.objects.get(title='Hit steps')
        self.assertTrue(goal.auto_track)
        self.assertEqual(goal.current_value, Decimal('8000'))

    def test_custom_category_cannot_enable_auto_track(self):
        response = self.client.post(reverse('goals:create'), {
            'title': 'Read more',
            'category': Goal.Category.CUSTOM,
            'target_value': '12',
            'current_value': '0',
            'unit': 'books',
            'auto_track': 'on',
        })
        self.assertEqual(response.status_code, 200)  # re-rendered with error
        self.assertFalse(Goal.objects.filter(title='Read more').exists())

    def test_manual_progress_update_rejected_for_auto_tracked_goal(self):
        goal = Goal.objects.create(
            user=self.user, title='Steps', category=Goal.Category.STEPS,
            target_value=Decimal('10000'), current_value=Decimal('5000'), auto_track=True,
        )
        response = self.client.post(reverse('goals:progress', args=[goal.pk]), {
            'current_value': '9999',
        })
        self.assertEqual(response.status_code, 302)
        goal.refresh_from_db()
        self.assertEqual(goal.current_value, Decimal('5000'))
