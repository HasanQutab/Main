from decimal import Decimal

from django.conf import settings
from django.db import models


class Goal(models.Model):
    class Category(models.TextChoices):
        STEPS = 'steps', 'Steps'
        WATER = 'water', 'Water'
        SLEEP = 'sleep', 'Sleep'
        WEIGHT = 'weight', 'Weight'
        CUSTOM = 'custom', 'Custom'

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='goals',
    )
    title = models.CharField(max_length=120)
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.CUSTOM)
    target_value = models.DecimalField(max_digits=8, decimal_places=1)
    current_value = models.DecimalField(max_digits=8, decimal_places=1, default=Decimal('0'))
    unit = models.CharField(max_length=20, blank=True, help_text='e.g. steps, ml, hours, kg')
    deadline = models.DateField(null=True, blank=True)
    is_achieved = models.BooleanField(default=False)
    auto_track = models.BooleanField(
        default=False,
        help_text=(
            'Automatically keep "Current" in sync with your health logs '
            '(steps, water, sleep) or profile weight, instead of updating it '
            'by hand. Not available for custom goals.'
        ),
    )
    created_at = models.DateTimeField(auto_now_add=True)

    # Categories that have a corresponding source of truth elsewhere in the
    # app (DailyLog fields, or Profile.weight_kg) and can therefore be
    # auto-tracked. CUSTOM has no such source, so it's excluded.
    AUTO_TRACKABLE_CATEGORIES = {Category.STEPS, Category.WATER, Category.SLEEP, Category.WEIGHT}

    class Meta:
        ordering = ('is_achieved', 'deadline', '-created_at')

    def __str__(self):
        return self.title

    @property
    def progress_percent(self):
        if not self.target_value:
            return 0
        percent = float(self.current_value) / float(self.target_value) * 100
        return max(0, min(round(percent), 100))

    def save(self, *args, **kwargs):
        if self.target_value and self.current_value >= self.target_value:
            self.is_achieved = True
        super().save(*args, **kwargs)

    def apply_auto_value(self, value):
        """Set current_value from an auto-tracked source and persist just
        the affected columns. No-op if auto_track is off, since a stale
        signal (e.g. a health log saved after auto_track was turned off)
        shouldn't silently overwrite a manually-entered value."""
        if not self.auto_track:
            return
        self.current_value = Decimal(str(value))
        self.save(update_fields=['current_value', 'is_achieved'])
