from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('goals', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='goal',
            name='auto_track',
            field=models.BooleanField(
                default=False,
                help_text=(
                    'Automatically keep "Current" in sync with your health logs '
                    '(steps, water, sleep) or profile weight, instead of updating it '
                    'by hand. Not available for custom goals.'
                ),
            ),
        ),
    ]
