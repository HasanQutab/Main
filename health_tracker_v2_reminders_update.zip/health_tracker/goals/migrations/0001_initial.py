from decimal import Decimal

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Goal',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=120)),
                ('category', models.CharField(choices=[('steps', 'Steps'), ('water', 'Water'), ('sleep', 'Sleep'), ('weight', 'Weight'), ('custom', 'Custom')], default='custom', max_length=20)),
                ('target_value', models.DecimalField(decimal_places=1, max_digits=8)),
                ('current_value', models.DecimalField(decimal_places=1, default=Decimal('0'), max_digits=8)),
                ('unit', models.CharField(blank=True, help_text='e.g. steps, ml, hours, kg', max_length=20)),
                ('deadline', models.DateField(blank=True, null=True)),
                ('is_achieved', models.BooleanField(default=False)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='goals', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'ordering': ('is_achieved', 'deadline', '-created_at'),
            },
        ),
    ]
