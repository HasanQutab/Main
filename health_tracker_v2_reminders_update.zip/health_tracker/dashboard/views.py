from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Avg
from django.shortcuts import render
from django.utils import timezone

from goals.models import Goal
from habits.models import Habit
from health.models import DailyLog
from health.recommendations import get_profile_for_user, get_recommended_targets, percent_of
from django.contrib.auth import get_user_model
from reminders.models import Reminder


@login_required
def home(request):
    user = request.user
    today = timezone.localdate()
    week_ago = today - timezone.timedelta(days=6)

    # --- Health: today's snapshot + 7-day averages ---
    today_log = DailyLog.objects.filter(user=user, date=today).first()
    week_logs = DailyLog.objects.filter(user=user, date__gte=week_ago, date__lte=today)
    week_averages = week_logs.aggregate(
        avg_steps=Avg('steps'),
        avg_water=Avg('water_ml'),
        avg_sleep=Avg('sleep_hours'),
    )

    # --- Habits: today's completion rate + average streak ---
    active_habits = list(Habit.objects.filter(user=user, is_active=True))
    completed_today = sum(1 for h in active_habits if h.is_completed_on(today))
    streaks = [h.current_streak() for h in active_habits]
    avg_streak = round(sum(streaks) / len(streaks), 1) if streaks else 0
    habit_completion_percent = (
        round(completed_today / len(active_habits) * 100) if active_habits else 0
    )

    # --- Goals: active/achieved counts + average progress ---
    goals = list(Goal.objects.filter(user=user))
    active_goals = [g for g in goals if not g.is_achieved]
    achieved_goals_count = len(goals) - len(active_goals)
    avg_goal_progress = (
        round(sum(g.progress_percent for g in active_goals) / len(active_goals))
        if active_goals else 0
    )

    # --- Reminders: next few upcoming ---
    upcoming_reminders = Reminder.objects.filter(
        user=user, is_active=True, remind_at__gte=timezone.now(),
    ).order_by('remind_at')[:3]

    # --- Personalized targets, from age/weight on the profile ---
    targets = get_recommended_targets(get_profile_for_user(user))
    steps_percent = percent_of(today_log.steps if today_log else 0, targets['steps'])
    water_percent = percent_of(today_log.water_ml if today_log else 0, targets['water_ml'])

    return render(request, 'dashboard/home.html', {
        'today_log': today_log,
        'steps_goal': targets['steps'],
        'water_goal': targets['water_ml'],
        'steps_percent': steps_percent,
        'water_percent': water_percent,
        'targets': targets,
        'week_averages': week_averages,
        'active_habits_count': len(active_habits),
        'completed_today': completed_today,
        'habit_completion_percent': habit_completion_percent,
        'avg_streak': avg_streak,
        'active_goals_count': len(active_goals),
        'achieved_goals_count': achieved_goals_count,
        'avg_goal_progress': avg_goal_progress,
        'upcoming_reminders': upcoming_reminders,
    })


@login_required
def staff_overview(request):
    """Cross-user reporting for staff. Not linked from the regular nav —
    visible in the sidebar only to users with is_staff=True.
    """
    if not request.user.is_staff:
        raise PermissionDenied('Staff access required.')

    User = get_user_model()

    total_users = User.objects.count()
    total_health_logs = DailyLog.objects.count()
    total_habits = Habit.objects.count()
    total_active_habits = Habit.objects.filter(is_active=True).count()
    total_goals = Goal.objects.count()
    total_goals_achieved = Goal.objects.filter(is_achieved=True).count()
    total_reminders = Reminder.objects.count()
    active_reminders = Reminder.objects.filter(is_active=True).count()

    return render(request, 'dashboard/staff_overview.html', {
        'total_users': total_users,
        'total_health_logs': total_health_logs,
        'total_habits': total_habits,
        'total_active_habits': total_active_habits,
        'total_goals': total_goals,
        'total_goals_achieved': total_goals_achieved,
        'total_reminders': total_reminders,
        'active_reminders': active_reminders,
    })
