import csv

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import HabitForm
from .models import Habit, HabitLog


@login_required
def habit_list(request):
    today = timezone.localdate()
    search = request.GET.get('q', '').strip()
    status = request.GET.get('status', 'active')  # active | inactive | all

    habits = Habit.objects.filter(user=request.user)
    if status == 'active':
        habits = habits.filter(is_active=True)
    elif status == 'inactive':
        habits = habits.filter(is_active=False)
    if search:
        habits = habits.filter(name__icontains=search)

    rows = [
        {
            'habit': habit,
            'completed_today': habit.is_completed_on(today),
            'streak': habit.current_streak(),
        }
        for habit in habits
    ]
    return render(request, 'habits/list.html', {
        'rows': rows,
        'today': today,
        'search': search,
        'status': status,
    })


@login_required
def habit_create(request):
    if request.method == 'POST':
        form = HabitForm(request.POST)
        if form.is_valid():
            habit = form.save(commit=False)
            habit.user = request.user
            habit.save()
            messages.success(request, 'Habit added.')
            return redirect('habits:list')
    else:
        form = HabitForm()
    return render(request, 'habits/form.html', {'form': form, 'is_edit': False})


@login_required
def habit_edit(request, pk):
    habit = get_object_or_404(Habit, pk=pk, user=request.user)
    if request.method == 'POST':
        form = HabitForm(request.POST, instance=habit)
        if form.is_valid():
            form.save()
            messages.success(request, 'Habit updated.')
            return redirect('habits:list')
    else:
        form = HabitForm(instance=habit)
    return render(request, 'habits/form.html', {'form': form, 'is_edit': True})


@login_required
def habit_delete(request, pk):
    habit = get_object_or_404(Habit, pk=pk, user=request.user)
    if request.method == 'POST':
        habit.delete()
        messages.success(request, 'Habit deleted.')
        return redirect('habits:list')
    return render(request, 'habits/confirm_delete.html', {'habit': habit})


@login_required
def habit_toggle_today(request, pk):
    habit = get_object_or_404(Habit, pk=pk, user=request.user)
    if request.method == 'POST':
        today = timezone.localdate()
        log, created = HabitLog.objects.get_or_create(habit=habit, date=today)
        if not created:
            log.delete()
    return redirect('habits:list')


@login_required
def habit_export(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="habits.csv"'

    writer = csv.writer(response)
    writer.writerow(['Habit', 'Description', 'Active', 'Current streak (days)', 'Created'])
    for habit in Habit.objects.filter(user=request.user):
        writer.writerow([habit.name, habit.description, habit.is_active, habit.current_streak(), habit.created_at])

    return response
