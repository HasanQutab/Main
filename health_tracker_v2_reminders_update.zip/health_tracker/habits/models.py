import datetime

from django.conf import settings
from django.db import models
from django.utils import timezone


class Habit(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='habits',
    )
    name = models.CharField(max_length=120)
    description = models.CharField(max_length=255, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('name',)

    def __str__(self):
        return self.name

    def is_completed_on(self, date):
        return self.logs.filter(date=date, completed=True).exists()

    def current_streak(self):
        """Consecutive days (ending today or yesterday) with a completed log."""
        completed_dates = set(
            self.logs.filter(completed=True).values_list('date', flat=True)
        )
        streak = 0
        cursor = timezone.localdate()
        if cursor not in completed_dates:
            cursor -= datetime.timedelta(days=1)
        while cursor in completed_dates:
            streak += 1
            cursor -= datetime.timedelta(days=1)
        return streak


class HabitLog(models.Model):
    habit = models.ForeignKey(Habit, on_delete=models.CASCADE, related_name='logs')
    date = models.DateField()
    completed = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-date',)
        constraints = [
            models.UniqueConstraint(fields=('habit', 'date'), name='unique_habit_log_per_day'),
        ]

    def __str__(self):
        return f'{self.habit.name} — {self.date}'
