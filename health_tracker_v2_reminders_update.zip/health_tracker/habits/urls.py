from django.urls import path

from . import views

app_name = 'habits'

urlpatterns = [
    path('habits/', views.habit_list, name='list'),
    path('habits/new/', views.habit_create, name='create'),
    path('habits/<int:pk>/edit/', views.habit_edit, name='edit'),
    path('habits/<int:pk>/delete/', views.habit_delete, name='delete'),
    path('habits/<int:pk>/toggle/', views.habit_toggle_today, name='toggle'),
    path('habits/export/', views.habit_export, name='export'),
]
